import { Component, OnInit } from '@angular/core';
import { LoginapiService } from '../shared/loginapi.service';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {
  customers: any = {};
  constructor(private services: LoginapiService) { }

  async ngOnInit(): Promise<void> {
    
  this.customers=  this.services.getData();
    


  }

}
